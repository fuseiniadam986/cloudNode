# CloudNode Panel v0.2.0-beta

第一阶段可运行 MVP，界面按最终确认的极简老 x-ui 风格实现。

## 当前已实现

- 后台登录与随机初始密码
- 后台默认只监听 `127.0.0.1:8088`
- 节点列表、搜索、刷新
- 添加节点弹窗：节点名称、域名/IP、端口
- 自动生成 UUID 与 XHTTP 路径
- 写配置前执行 `xray run -test`
- 创建失败自动撤销节点记录
- 删除节点
- Xray 服务状态与重启
- 复制成功 Toast
- systemd + Gunicorn 部署

## 当前 Beta 暂未实现

UI 讨论中的多协议一键生成、统一订阅二维码、二维码刷新、自动 TLS、BBR、流量统计、完整编辑弹窗尚未接入真实后端。不要把这些功能写进 GitHub Release 的“已完成”列表。

## 安装

目标：Debian / Ubuntu，服务器上已经安装 Xray-core。

```bash
cd CloudNode-Panel-v0.2.0-beta
sudo bash install.sh
```

安装器会打印随机初始密码。面板只监听本机 8088，建议通过 SSH 隧道或受保护的 HTTPS 反向代理访问。

## 重要说明

这是 Beta。尚未在真实公网 VPS 上完成端到端客户端连接、TLS、升级回滚等生产验收。
